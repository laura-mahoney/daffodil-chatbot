# File generated from our OpenAPI spec by Stainless.

__title__ = "openai"
__version__ = "1.12.0"  # x-release-please-version
